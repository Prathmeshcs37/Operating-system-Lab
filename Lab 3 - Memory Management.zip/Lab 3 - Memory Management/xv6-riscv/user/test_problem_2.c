#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
	char *string[argc-1];
	
	for(int i=1;i<argc;i++)
	{
		string[i-1]=argv[i];
	}
		
	if(argc>=2)
	{
		if(echo_kernel(argc-1,string)<0)
		{
			printf("incorrect call\n");
			exit(1);
		}
	}
	
  exit(0);
}

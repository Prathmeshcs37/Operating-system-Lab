#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/processinfo.h"

int
main()
{
	struct processinfo x;
	get_process_info(&x);
	
	printf("Process ID -> %d\n",x.pid);
	printf("Process Name -> %s\n",x.name);
	printf("Memory size -> %d Bytes\n",x.sz);
	
	exit(0);
}

struct processinfo {
    int pid;
    char name[16];
    uint64 sz;
};